from keras.models import Sequential
from keras.layers.core import Dense
from keras.utils import np_utils
from sklearn.preprocessing import LabelEncoder

import pandas as pd


# 데이터 입력
df = pd.read_csv('./dataset/iris.csv', names = ["sepal_length", "sepal_width", "petal_length", "petal_width", "species"])
#print(df.head())


# 데이터 분류
dataset = df.values
X = dataset[:,[0,1,2,3]]
Y_obj = dataset[:,4]

# 문자열을 숫자로 변환
e = LabelEncoder()
e.fit(Y_obj)
Y = e.transform(Y_obj)
Y_encoded = np_utils.to_categorical(Y)

# 모델의 설정
model = Sequential()
model.add(Dense(16,  input_dim=4, activation='relu'))
model.add(Dense(24, activation='relu')) # 은닉층 추가
model.add(Dense(3, activation='softmax'))

# 모델 컴파일
model.compile(loss='mean_squared_error',
            optimizer='adam',
            metrics=['accuracy'])

# 모델 실행
model.fit(X, Y_encoded, epochs=50, batch_size=1)

# 결과 출력
print("\n Accuracy: %.4f" % (model.evaluate(X, Y_encoded)[1]))

#----------------------------------------------------
# 새로운 속성을 입력하여 예측값 출력하기
import numpy as np
X_new = X[0:5, :]
predictions = model.predict(X_new)

print("예측값: %s" %predictions[0]) # 5개 중 첫번째 샘플에 대한 예측값
print("예측값의 합: %d" %np.sum(predictions[0])) # 첫번째 샘플에 대한 예측값을 더했을 때 1이 되는지 확인
print("예측 클래스: %d" %np.argmax(predictions[0])) # 첫번째 샘플에 대한 예측값에 의해 확률이 가장 높은 클래스를 선택
#----------------------------------------------------





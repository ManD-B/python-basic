#===========================
import tensorflow as tf
import numpy as np
# seed 값 설정
seed = 1
np.random.seed(seed)
tf.set_random_seed(seed)
#===========================

# 필요한 라이브러리
from keras.models import Sequential
from keras.layers.core import Dense
from keras.utils import np_utils
from sklearn.preprocessing import LabelEncoder
import pandas as pd
# 데이터 불러오기
df = pd.read_csv('HW01_dataset.csv', names = ["Number","RI  refractive index",
"Na  Sodium", "Mg  Magnesium", "Al  Aluminum","Si  Silicon","K  Potassium","Ca  Calcium","Ba  Barium","Fe  Iron","Type of Glass"])
dataset = df.values
X = dataset[:,1:10] # 속성
Y_obj = dataset[:,10] # 클래스

e = LabelEncoder()
e.fit(Y_obj)
Y = e.transform(Y_obj)
Y_encoded = np_utils.to_categorical(Y)

model = Sequential()
model.add(Dense(500, input_dim=9, activation='relu')) # 입력층과 은닉층
model.add(Dense(500, activation='sigmoid')) # 출력층
model.add(Dense(6, activation='softmax')) # 출력층
# 모델 컴파일
model.compile(loss='categorical_crossentropy',
optimizer='adam',
metrics=['accuracy'])
# 모델 학습 실행
model.fit(X, Y_encoded, epochs=300, batch_size=25)
# 결과 출력
print("\n Accuracy: %.4f" % (model.evaluate(X, Y_encoded)[1]))

